#include "system/video/screens/loading.h"
#include "system/video/screens/result_font.h"
#include "system/audio/audio.h"
#include "system/audio/music.h"
#include "system/audio/sfx.h"
#include "system/video/spritelist.h"
#include "interface_data.h"

// A compact resistance panel borrows only the existing system colour tiles.
// Its paper/steel/rivet pixels and palette come from the game's own interface.
#define FIRST 2
#define GLYPHS 6
#define PAPER 8
#define INK 9
#define STEEL 10
#define TOP 11
#define CORNER 12
#define SIDE 13
#define SHADOW 14
#define RIVET 15
#define TILES 14
static u8 workDepth;
static volatile bool loadingActive;
static volatile u8 loadingDigit;
static u32 serviceFrame,loadingStart;
static u16 loadingMinimum,desiredPalette[16];
static u16 savedTiles[TILES*16];
static u16 savedWindow[64*3]; // only HUD rows are visible once play begins
static u8 oldWindowX,oldWindowY;
static u16 loadingFrames;

static void readVRAM(u16 address,u16 *dest,u16 words)
{
    volatile u16 *data=(u16 *)VDP_DATA_PORT;
    volatile u32 *ctrl=(u32 *)VDP_CTRL_PORT;
    SYS_disableInts();VDP_setAutoInc(2);*ctrl=VDP_READ_VRAM_ADDR(address);
    while(words--)*dest++=*data;
    SYS_enableInts();
}
static void audioFrame(void)
{
    AUDIO_frameBegin();MUSIC_update();SFX_update();AUDIO_frameEnd();
}
void LOADING_workBegin(void)
{
    if(!workDepth)serviceFrame=vtimer;
    workDepth++;
}
void LOADING_workEnd(void){if(workDepth)workDepth--;}
bool LOADING_active(void){return loadingActive;}
void LOADING_setEnable(bool enabled){if(!loadingActive)VDP_setEnable(enabled);}
void LOADING_windowOff(void){if(!loadingActive)VDP_setWindowOff();}
void LOADING_setColor(u16 index,u16 color)
{
    if(loadingActive && index<16)desiredPalette[index]=color;
    else PAL_setColor(index,color);
}
void LOADING_setColors(u16 index,const u16 *colors,u16 count,TransferMethod method)
{
    if(!loadingActive){PAL_setColors(index,colors,count,method);return;}
    // Apply immediately during loading: a deferred palette must not overwrite
    // the overlay at the next VBlank or retain a caller's stack buffer.
    for(u16 i=0;i<count;i++)LOADING_setColor(index+i,colors[i]);
}
void LOADING_getColors(u16 index,u16 *colors,u16 count)
{
    PAL_getColors(index,colors,count);
    if(loadingActive)for(u16 i=0;i<count;i++) {
        if(index+i<16)colors[i]=desiredPalette[index+i];
    }
}
void LOADING_tiles(const u32 *data,u16 index,u16 count,TransferMethod method)
{
    if(!workDepth || method!=DMA){VDP_loadTileData(data,index,count,method);return;}
    while(count) {
        const u16 chunk=count>64 ? 64 : count;
        VDP_loadTileData(data,index,chunk,DMA);LOADING_poll();
        data+=chunk*8;index+=chunk;count-=chunk;
    }
}
void LOADING_copyVRAM(const u16 *data,u16 address,u16 words)
{
    while(words) {
        const u16 chunk=words>1024 ? 1024 : words;
        DMA_doDma(DMA_VRAM,(void *)data,address,chunk,2);LOADING_poll();
        data+=chunk;address+=chunk*2;words-=chunk;
    }
}
static void cell(u16 tile,u16 x,u16 y,bool flipX,bool flipY)
{
    VDP_setTileMapXY(WINDOW,TILE_ATTR_FULL(PAL0,TRUE,flipY,flipX,tile),x,y);
}
static void animate(void)
{
    const u32 elapsed=vtimer-loadingStart;
    const u16 second=loadingMinimum>=3 ? loadingMinimum/3 : 1;
    const u8 digit=elapsed<second ? 3 : elapsed<second*2 ? 2 : 1;
    if(digit==loadingDigit)return;
    loadingDigit=digit;
    VDP_fillTileMapRect(WINDOW,TILE_ATTR_FULL(PAL0,TRUE,FALSE,FALSE,PAPER),11,7,18,17);
    // The game's native 8x8 glyph, enlarged in whole tiles, with a copper
    // shadow. No temporary bitmap competes with the destination stage art.
    for(u16 layer=0;layer<2;layer++)for(u16 y=0;y<8;y++) {
        const u8 bits=RESULT_FONT[('0'+digit-32)*8+y];
        for(u16 x=0;x<8;x++)if(bits&(0x80>>x)) {
            const u16 offset=layer ? 0 : 1;
            VDP_fillTileMapRect(WINDOW,TILE_ATTR_FULL(PAL0,TRUE,FALSE,FALSE,layer ? INK : SHADOW),12+x*2+offset,7+y*2+offset,2,2);
        }
    }
    for(u16 i=0;i<3;i++)cell(i<4-digit ? INK : SHADOW,17+i*2,25,FALSE,FALSE);
    SFX_countPulse(FALSE);
}
void LOADING_poll(void)
{
    if(!workDepth || serviceFrame==vtimer)return;
    serviceFrame=vtimer;
    if(loadingActive){animate();loadingFrames++;}
    audioFrame();
    // Work proceeds within the current video frame. Waiting here would make
    // every following checkpoint look overdue and turn small chunks into
    // hundreds of compulsory idle frames. Screen owners flush queued DMA.
}
void LOADING_begin(u16 minimumFrames)
{
    LOADING_workBegin();
    SPRITES_hide();SYS_doVBlankProcess();VDP_setEnable(FALSE);
    readVRAM(FIRST*32,savedTiles,TILES*16);
    readVRAM(VDP_WINDOW,savedWindow,64*3);
    oldWindowX=VDP_getReg(17);oldWindowY=VDP_getReg(18);
    PAL_getColors(0,desiredPalette,16);
    u32 tiles[TILES*8];
    const char *glyphs="PREA-S";
    for(u16 i=0;i<TILES*8;i++)tiles[i]=0x88888888UL;
    for(u16 i=0;i<GLYPHS;i++)for(u16 y=0;y<8;y++) {
        const u8 bits=RESULT_FONT[((u8)glyphs[i]-32)*8+y];
        u32 word=0;
        for(u16 x=0;x<8;x++)word=(word<<4)|((bits&(0x80>>x)) ? 1 : 8);
        tiles[i*8+y]=word;
    }
    for(u16 y=0;y<8;y++) {
        tiles[(INK-FIRST)*8+y]=0xCCCCCCCCUL;
        tiles[(STEEL-FIRST)*8+y]=0x99999999UL;
        tiles[(SHADOW-FIRST)*8+y]=0x66666666UL;
    }
    const u16 *map=(const u16 *)interface_map;
    const u32 *art=(const u32 *)interface_tiles;
    memcpy(tiles+(PAPER-FIRST)*8,art+map[14*40+20]*8,32);
    memcpy(tiles+(TOP-FIRST)*8,art+map[1]*8,32);
    memcpy(tiles+(CORNER-FIRST)*8,art+map[0]*8,32);
    memcpy(tiles+(SIDE-FIRST)*8,art+map[40]*8,32);
    memcpy(tiles+(RIVET-FIRST)*8,art+map[41]*8,32);
    VDP_loadTileData(tiles,FIRST,TILES,DMA);
    VDP_fillTileMapRect(WINDOW,TILE_ATTR_FULL(PAL0,TRUE,FALSE,FALSE,PAPER),0,0,40,28);
    for(u16 x=0;x<40;x++) {
        cell(TOP,x,0,FALSE,FALSE);cell(TOP,x,27,FALSE,TRUE);
        if(x>0 && x<39){cell(STEEL,x,1,FALSE,FALSE);cell(STEEL,x,26,FALSE,FALSE);}
    }
    for(u16 y=1;y<27;y++) {
        cell(SIDE,0,y,FALSE,FALSE);cell(SIDE,39,y,TRUE,FALSE);
        cell(STEEL,1,y,FALSE,FALSE);cell(STEEL,38,y,FALSE,FALSE);
    }
    cell(CORNER,0,0,FALSE,FALSE);cell(CORNER,39,0,TRUE,FALSE);
    cell(CORNER,0,27,FALSE,TRUE);cell(CORNER,39,27,TRUE,TRUE);
    cell(RIVET,1,1,FALSE,FALSE);cell(RIVET,38,1,TRUE,FALSE);
    cell(RIVET,1,26,FALSE,TRUE);cell(RIVET,38,26,TRUE,TRUE);
    for(u16 x=4;x<36;x++){cell(TOP,x,6,FALSE,FALSE);cell(TOP,x,24,FALSE,TRUE);}
    const char *title="PREPARE-SE";
    for(u16 i=0;title[i];i++) {
        u16 glyph=0;while(glyphs[glyph]!=title[i])glyph++;
        cell(FIRST+glyph,15+i,4,FALSE,FALSE);
    }
    PAL_setColors(0,(const u16 *)interface_palette,16,DMA);
    VDP_setWindowFullScreen();
    loadingMinimum=minimumFrames;loadingFrames=0;loadingDigit=0;
    loadingStart=vtimer;loadingActive=TRUE;animate();
    VDP_setEnable(TRUE);
    // Count from the first complete visible frame, not from fade-out/setup.
    SYS_doVBlankProcess();loadingStart=serviceFrame=vtimer;
    audioFrame();
}
void LOADING_end(void)
{
    if(!loadingActive)return;
    while(vtimer-loadingStart<loadingMinimum) {
        animate();audioFrame();loadingFrames++;serviceFrame=vtimer;
        SYS_doVBlankProcess();
    }
    // All queued destination transfers must finish before returning ownership.
    SYS_doVBlankProcess();VDP_setEnable(FALSE);
    loadingActive=FALSE;
    VDP_loadTileData((const u32 *)savedTiles,FIRST,TILES,DMA);
    VDP_setTileMapData(VDP_WINDOW,savedWindow,0,64*3,2,CPU);
    PAL_setColors(0,desiredPalette,16,DMA);
    VDP_setReg(17,oldWindowX);VDP_setReg(18,oldWindowY);
    LOADING_workEnd();
    SFX_countPulse(TRUE);
}
